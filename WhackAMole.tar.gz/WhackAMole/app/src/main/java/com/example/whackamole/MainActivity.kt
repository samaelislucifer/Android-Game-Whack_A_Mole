package com.example.whackamole

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        easy.setOnClickListener {
            intent = Intent(this,easyActivity::class.java)
            startActivity(intent)
        }
        normal.setOnClickListener {
            intent = Intent(this,normalActivity::class.java)
            startActivity(intent)
        }
        difficult.setOnClickListener {
            intent = Intent(this,difficultActivity::class.java)
            startActivity(intent)
        }
    }
}
