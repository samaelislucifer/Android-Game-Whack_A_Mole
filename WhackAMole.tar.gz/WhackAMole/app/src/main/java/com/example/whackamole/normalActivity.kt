package com.example.whackamole

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_normal.*
import java.util.*
import kotlin.collections.ArrayList

class normalActivity: AppCompatActivity(){
    var score:Int = 0
    var images = ArrayList<ImageView>()
    var handler: Handler = Handler()
    var runnable:Runnable= Runnable {  }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_normal)

        next.setOnClickListener{
            intent = Intent(this,difficultActivity::class.java)
            startActivity(intent)
        }
        restart.setOnClickListener{
            intent = Intent(this,normalActivity::class.java)
            startActivity(intent)
        }
        object: CountDownTimer(20000,1000){
            override fun onFinish() {
                timeText.text="Time's Up"
                handler.removeCallbacks(runnable)
                for(i in images){
                    i.visibility= View.INVISIBLE
                }
            }

            override fun onTick(p0: Long) {
                timeText.text="Time : "+p0/1000
            }
        }.start()
        images= arrayListOf(imageView00,imageView01,imageView02,imageView03,imageView04,imageView10,imageView11,imageView12,imageView13,imageView14,imageView20,imageView21,imageView22,imageView23,imageView24,imageView30,imageView31,imageView32,imageView33,imageView34,imageView40,imageView41,imageView42,imageView43,imageView44,imageView50,imageView51,imageView52,imageView53,imageView54,imageView60,imageView61,imageView62,imageView63,imageView64)
        hideImages()
    }


    fun increaseScore(view: View){
        score++
        scoreText.text="Score : "+score

    }
    fun hideImages() {
        runnable = object : Runnable {
            override fun run() {
                for (i in images) {
                    i.visibility = View.INVISIBLE
                }
                val random = Random()
                val index = random.nextInt(34 - 0)
                images[index].visibility = View.VISIBLE
                handler.postDelayed(runnable, 700)
            }
        }
        handler.post(runnable)
    }
}